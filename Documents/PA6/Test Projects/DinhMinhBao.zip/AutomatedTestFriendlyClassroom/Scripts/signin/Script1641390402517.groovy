import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import org.openqa.selenium.WebElement as WebElement
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory

WebUI.openBrowser('http://localhost:3000')

WebUI.click(findTestObject('Page_Friendly Classroom/home/button_signin_home'))

WebUI.delay(1)

WebUI.setText(findTestObject('Page_Friendly Classroom/signin/input_username_signin'), 'yass')

WebUI.setText(findTestObject('Page_Friendly Classroom/signin/input_password_signin'), 'yass')

WebUI.click(findTestObject('Page_Friendly Classroom/signin/button_signin_signin'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Friendly Classroom/home2/div_statistic_applied_math_home2'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Friendly Classroom/class/a_everyone_class'))

WebUI.delay(1)

WebUI.click(findTestObject('Page_Friendly Classroom/class/div_add_people_class'))

WebUI.setText(findTestObject('Page_Friendly Classroom/class/input_Username_add'), username)

WebUI.click(findTestObject('Page_Friendly Classroom/class/button_ok_add_people_class'))

WebUI.delay(1)

if (can_be_added.equals('true')) {
    is_notify_success_ok = WebUI.verifyElementVisible(findTestObject('Page_Friendly Classroom/class/div_add_success'), FailureHandling.STOP_ON_FAILURE)

    assert is_notify_success_ok

    println(is_notify_success_ok)

    WebUI.refresh(FailureHandling.STOP_ON_FAILURE)
	
	number_of_username=0

    WebDriver driver = DriverFactory.getWebDriver()

    WebElement Table = driver.findElement(By.xpath('//div[@id=\'root\']/div[3]/div/div'))

    List<WebElement> rows_table = Table.findElements(By.tagName('tr'))

    int rows_count = rows_table.size()

    is_name_ok = false

    for (int row = 0; row < rows_count; row++) {
        List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName('td'))

        int columns_count = Columns_row.size()

        if (columns_count > 2) {
            String celltext = Columns_row.get(1).getText()

            println(celltext)

            if (celltext.equals(username)) {
                is_name_ok = true
				number_of_username=number_of_username+1
            }
        }
    }
    
    assert (is_name_ok && number_of_username==1)
} else {
    if (why_cant_be_added.equals('not exists')) {
        is_ok = WebUI.verifyElementVisible(findTestObject('Page_Friendly Classroom/class/div_not_exists_add_people_class'), 
            FailureHandling.STOP_ON_FAILURE)
    } else if (why_cant_be_added.equals('joined')) {
        is_ok = WebUI.verifyElementVisible(findTestObject('Page_Friendly Classroom/class/div_joined'), FailureHandling.STOP_ON_FAILURE)
    } else {
        is_ok = WebUI.verifyElementVisible(findTestObject('Page_Friendly Classroom/class/div_not_empty_add_people_class'), 
            FailureHandling.STOP_ON_FAILURE)
    }
    
    assert is_ok

    WebUI.click(findTestObject('Page_Friendly Classroom/class/button_cancel_add_people_class'))
	number_of_username=0
        WebUI.refresh(FailureHandling.STOP_ON_FAILURE)

        WebDriver driver = DriverFactory.getWebDriver()

        WebElement Table = driver.findElement(By.xpath('//div[@id=\'root\']/div[3]/div/div'))

        List<WebElement> rows_table = Table.findElements(By.tagName('tr'))

        int rows_count = rows_table.size()

        is_name_ok = false

        for (int row = 0; row < rows_count; row++) {
            List<WebElement> Columns_row = rows_table.get(row).findElements(By.tagName('td'))

            int columns_count = Columns_row.size()

            if (columns_count > 2) {
                String celltext = Columns_row.get(1).getText()

                println(celltext)

                if (celltext.equals(username)) {
                    is_name_ok = true
					number_of_username=number_of_username+1
                }
            }
        }
        
        if(!why_cant_be_added.equals("joined")) {
			 assert !(is_name_ok)
        }
		else {
			assert(number_of_username==1)
		}
		
}

WebUI.closeBrowser()

