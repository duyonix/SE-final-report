<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Run 2 Test Case</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>d6180823-1012-4e94-a0b0-705bf2800e1a</testSuiteGuid>
   <testCaseLink>
      <guid>a7610978-5f22-4add-b16e-c64e02239417</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create Classroom Failed With Existing Name</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>768968c9-63a6-426d-a09e-2f65b2b56c32</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Create Classroom Failed With Existing Name Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>768968c9-63a6-426d-a09e-2f65b2b56c32</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Tenlophoc</value>
         <variableId>31db8c1c-03a7-41c7-bef5-095b11dc0fb3</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>6dd26bf3-6574-4cad-b421-7d497bf04c17</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Create Classroom Success</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>8f7fcd7f-b0a1-4a20-b168-6f4695e1b741</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Create Classroom Success Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>8f7fcd7f-b0a1-4a20-b168-6f4695e1b741</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>ClassName</value>
         <variableId>d23702a5-2488-4aaf-9f0f-6d444faf2c13</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>8f7fcd7f-b0a1-4a20-b168-6f4695e1b741</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>ClassDescription</value>
         <variableId>a9407a07-53e3-4d0e-b770-d764e56047f5</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>8f7fcd7f-b0a1-4a20-b168-6f4695e1b741</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>Verify ClassName</value>
         <variableId>aefa6561-bb16-4373-843e-f62e397aed14</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
