<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Tham gia lớp học</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>f7fd3262-3ddf-48da-9f9d-716200b34584</testSuiteGuid>
   <testCaseLink>
      <guid>3b26592c-50cc-4fbd-99ce-f20bfec4b967</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tham gia lớp học_Fail_đã tham gia với vai trò học sinh</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>f015cc58-57af-4457-8618-3f456545cb43</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Tham gia lớp học fail Test Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>f015cc58-57af-4457-8618-3f456545cb43</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>malophoc</value>
         <variableId>1d72c0ca-c495-42e5-b37f-efb83eeafa32</variableId>
      </variableLink>
   </testCaseLink>
   <testCaseLink>
      <guid>3603d652-e158-41da-837a-98fd13deeb3f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Tham gia lớp học_Success</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>04b6faec-15e2-4388-8a65-3a5c0005085b</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/Tham gia lớp học success Test Data</testDataId>
      </testDataLink>
      <variableLink>
         <testDataLinkId>04b6faec-15e2-4388-8a65-3a5c0005085b</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>malophoc</value>
         <variableId>98b88a0f-dd8a-4214-a101-5f5f21158863</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
