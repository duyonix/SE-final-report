<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite Assign Homework With New Topic</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>ab65936c-0208-41b1-985d-3f2985f9199e</testSuiteGuid>
   <testCaseLink>
      <guid>b977b30e-8b77-4cff-8b30-98e86080321c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework With New Topic/Test Case Assign Homework With New Topic - Input 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>832903d4-feef-452c-9343-769921948eab</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework With New Topic/Test Case Assign Homework With New Topic - Input 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0a42d5b0-de6f-496f-9265-9aad7b4a2454</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework With New Topic/Test Case Assign Homework With New Topic - Input 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>06152712-25e5-45b1-8422-fe94cb61dd26</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework With New Topic/Test Case Assign Homework With New Topic - Input 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>5af2071d-62b8-4313-b5c4-5d5619a8dbc6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework With New Topic/Test Case Assign Homework With New Topic - Input 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
