<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Test Suite Assign Homework Has Duplicate Title</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>88be3f5f-dad4-4d61-9fe1-7ecb4f138e0f</testSuiteGuid>
   <testCaseLink>
      <guid>d7a21f7b-5d81-4ce7-9aec-a8942971ef65</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework Has Duplicate Title/Test Case Assign Homework Has Duplicate Title - Input 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b4226d64-751b-4ac0-bcd7-0a2a309d1244</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework Has Duplicate Title/Test Case Assign Homework Has Duplicate Title - Input 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fc8e1dd9-4d63-4c14-91c2-e40100f2cd98</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework Has Duplicate Title/Test Case Assign Homework Has Duplicate Title - Input 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d9830461-d464-4af2-97d8-7c4a4a5ec0f2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework Has Duplicate Title/Test Case Assign Homework Has Duplicate Title - Input 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0d1d5c82-4729-4c9b-b146-028758216208</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test Case Assign Homework Has Duplicate Title/Test Case Assign Homework Has Duplicate Title - Input 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
