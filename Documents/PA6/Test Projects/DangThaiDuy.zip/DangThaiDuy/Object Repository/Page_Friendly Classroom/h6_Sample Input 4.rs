<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h6_Sample Input 4</name>
   <tag></tag>
   <elementGuidId>ece0242e-da0b-4651-a65f-d058c62b0aab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h6.MuiTypography-root.MuiTypography-h6.css-2ulfj5-MuiTypography-root</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='vertical-tabpanel-0']/div/div/div/div/div/h6</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h6</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-h6 css-2ulfj5-MuiTypography-root</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sample Input 4</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;vertical-tabpanel-0&quot;)/div[@class=&quot;MuiBox-root css-14ldegz&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;box-homework-content MuiBox-root css-0&quot;]/div[@class=&quot;section MuiBox-root css-0&quot;]/div[@class=&quot;section MuiBox-root css-0&quot;]/h6[@class=&quot;MuiTypography-root MuiTypography-h6 css-2ulfj5-MuiTypography-root&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='vertical-tabpanel-0']/div/div/div/div/div/h6</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Không có chủ đề'])[1]/following::h6[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sample'])[1]/following::h6[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Bài tập mẫu 4 với chủ đề Sample Input 4'])[1]/preceding::h6[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h6</value>
   </webElementXpaths>
</WebElementEntity>
