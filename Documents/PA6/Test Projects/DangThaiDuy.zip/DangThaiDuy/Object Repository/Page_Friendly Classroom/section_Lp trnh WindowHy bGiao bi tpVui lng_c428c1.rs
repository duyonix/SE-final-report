<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>section_Lp trnh WindowHy bGiao bi tpVui lng_c428c1</name>
   <tag></tag>
   <elementGuidId>0f89fec2-3ec7-4ef7-82a0-8be2af931831</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>section.assign-homework.container</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/section</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>section</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>assign-homework container</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Lập trình WindowHủy bỏGiao bài tậpVui lòng điền đầy đủ tiêu đề, hạn nộp và chủ đề bài tậpTiêu đề *Mô tả nội dungKéo thả hoặc ấn vào đây để đăng tải fileĐiểm--Hạn nộp--Chủ đềKhông có chủ đềVui lòng điền đầy đủ tiêu đề, hạn nộp và chủ đề bài tậpHủy bỏGiao bài tập</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/section[@class=&quot;assign-homework container&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/section</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Điểm số'])[1]/following::section[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mọi người'])[1]/following::section[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//section</value>
   </webElementXpaths>
</WebElementEntity>
