import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('http://localhost:3000/')

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/button_ng nhp'))

WebUI.setText(findTestObject('Object Repository/Page_Friendly Classroom/input_Tn ng nhp_username'), 'yass')

WebUI.setEncryptedText(findTestObject('Object Repository/Page_Friendly Classroom/input_Mt khu_password'), 'j6T4a23zmIA=')

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/button_ng nhp_1'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/div_Lp trnh Window1 thnh vin'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/a_Bi tp'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/button_Thm'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/li_Bi Tp'))

WebUI.setText(findTestObject('Object Repository/Page_Friendly Classroom/input_Tiu_title'), 'Sample Homework')

WebUI.setText(findTestObject('Object Repository/Page_Friendly Classroom/textarea_M t ni dung_description'), 'Input 2\nHoàn thành đầy đủ và nhớ nộp bài nha các em')

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/input_-_mui-38'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/button_31'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/div__css-1umqo6f'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/button_OK'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/div_Khng c ch_css-6j8wv5-Input'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/div_Sample'))

WebUI.click(findTestObject('Object Repository/Page_Friendly Classroom/button_Giao bi tp'))

WebUI.verifyElementText(findTestObject('Page_Friendly Classroom/div_Vui lng in y  tiu , hn np v ch  bi tp'), 'Không thể có 2 bài tập về nhà cùng tên được')

WebUI.closeBrowser()

