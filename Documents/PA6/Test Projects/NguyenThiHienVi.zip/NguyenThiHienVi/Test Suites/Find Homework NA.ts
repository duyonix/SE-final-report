<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Find Homework NA</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>b4e60218-171c-4789-b1a2-98a591ca3288</testSuiteGuid>
   <testCaseLink>
      <guid>a1ece49b-ac21-4369-8eb4-0af37002b1f0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework not available/Find na 1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d2bc68af-b9f4-491c-bca0-45daa05898eb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework not available/Find na 2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d2eae7e1-563b-414b-a370-cc52cd2d6de2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework not available/Find na 3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b634637e-0e78-467f-86e0-2be9c022034b</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework not available/Find na 4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0ba319e5-d7eb-4bf8-b9f7-a4bc7d021336</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework not available/Find na 5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
