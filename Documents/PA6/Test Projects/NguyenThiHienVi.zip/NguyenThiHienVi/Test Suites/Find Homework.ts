<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Find Homework</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>815ea295-dd7e-4116-b5d6-71132aa697b1</testSuiteGuid>
   <testCaseLink>
      <guid>bf350732-c771-49cc-a302-266e79c547a7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework available/Find1</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>fa26dc34-d7cf-4897-859e-f5ba0d7278c1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework available/Find2</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>aa3c7db7-02f2-4fe2-a6f1-3980f2e92a49</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework available/Find3</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>95df9a5a-512a-4851-b9b1-c58c883ca977</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework available/Find4</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8ef21c94-7d88-48e0-8451-560a401a3e39</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Find Homework available/Find5</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
